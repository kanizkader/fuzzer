class PdfHandler:
    @staticmethod
    def parse_input(example_input):
        return ["pee dee eff"]
